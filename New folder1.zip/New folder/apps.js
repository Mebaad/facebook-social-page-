
// click event for user profile


var settings-menu = document.querySelector(".settings-menu");

function settingsMenuToggle(){
 
    settings-menu.classList.toggle("settings-menu-height");
}
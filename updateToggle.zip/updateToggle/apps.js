
// click event for user profile


var settings_menu = document.querySelector(".settings-menu");

function settingsMenuToggle(){
 
    settings_menu.classList.toggle("settings-menu-height");
}